package com.oneearth.shetkari.Models

data class Clouds(
    val all: Int
)