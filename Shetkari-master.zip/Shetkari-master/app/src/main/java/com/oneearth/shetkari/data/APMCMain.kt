package com.oneearth.shetkari.data

data class APMCMain(val updated_date: String, val records: List<APMCRecords>)