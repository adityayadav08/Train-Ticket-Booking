package com.oneearth.shetkari.Models

data class Rain(
    val `1h`: Double
)