package com.oneearth.shetkari.Models

data class Coord(
    val lat: Double,
    val lon: Double
)